#include"character.h"
#include"game.h"

character::character()
{
	this->name = { "" };
	this->level = 1;
	this->exp = 1;
	//algorithm to level up and so that exp increases per level up
	this->expnext = pow(level, 3) - 6 * pow(level, 3) + (17 * level) - 11;
	this->health = 200;
	this->maxhealth = 200;
	this-> sworddamage=50;

}
character::~character()
{

}
string character::getname() const
{
	return name;
}
void character::setname(string x)
{
	name=x;
}
double character::getex()
{
	return exp;
}
void character::setex(double x)
{
	x=exp;
}
int character::getlevel()
{
	return level;
}
void character::setlevel(int x)
{
	level=x;
}
void character::tostring()
{
	cout << "Name: " << this->name<<endl;
	cout << "Level: " << this->level<<endl;
	cout << "Experience points: " << this->exp << endl;
	cout << "Experience points needed for next level up: " << this->expnext << endl;
	cout << "Health: " << this->health << endl;
}
void character::levelup()
//found this level up algorithm that inc exp required
//for next level up once level inc
{
	if (exp >= expnext)
	{
		this->exp -= this->expnext;
		level++;
		expnext = pow(level, 3) - 6 * pow(level, 3) + (17 * level) - 11;

	}
}
double character::gethealth()
{
	return health;
}
void character::sethealth(double x)
{
	x = health;
}
double character:: maxihealth()
{
	return maxhealth;
}
void character::healingspel()
{
	health += healingspell;
	if (health >= maxhealth)
	{
		health = maxhealth;
	}
}
void character::healingpot()
{
	health += healingpotion;
	if (health >= maxhealth)
	{
		health = maxhealth;
	}
}


