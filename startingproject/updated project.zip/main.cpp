#include"game.h"
#include<iostream>
#include<string>
using namespace std;
int main()
{
	Game game;
	while (game.getplaying()==true)
	{
		game.mainmenu();
		//start going through story

	}

}