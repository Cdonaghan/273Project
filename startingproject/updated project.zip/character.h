#pragma once
#include"game.h"
#include<string>
#include<iostream>
#include<math.h>
using namespace std;
class character
{
public:
	character();
	virtual ~character();
	void tostring();//user can access player information

	string getname() const;
	void setname(string x);

	int getlevel();
	void setlevel(int x);

	double getex();
	void setex(double x);

	double gethealth();
	void sethealth(double x);

	void healingspel();
	void healingpot();

	double maxihealth();
	void levelup();
private:
	string name;
	int level;
	double exp;
	double expnext;
	double health;
	double maxhealth;
	double sworddamage;
	double explosionspell;
	double attackspell;
	double healingspell;
	double healingpotion;
};

